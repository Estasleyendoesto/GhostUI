﻿local _, ns = ...
local About = gUI:NewModule("About", "AceEvent-3.0")

local MainFrame = gUI:GetModule("MainFrame")
local Utils     = gUI:GetModule("Utils")
local Text      = gUI:GetModule("Text")
local Link      = gUI:GetModule("Link")

local PANEL_NAME = "About"

function About:OnEnable()
    self:RegisterMessage("GHOSTUI_PANEL_CHANGED", "OnEnter")
end

function About:OnEnter(_, panel)
    if panel == PANEL_NAME then self:Draw() end
end

function About:Draw()
    -- 1. Preparar el contenedor
    -- Ocultamos el scrollbar porque el contenido es corto y queda mejor visualmente
    MainFrame.ScrollFrame.ScrollBar:Hide()
    MainFrame:ClearAll()
    
    local container = MainFrame.Content

    -- 2. Branding y Versión
    Text:CreateHeadLine(container, "GhostUI", "gUI - 1.2.0")

    -- 3. Autoría (Configuración centrada)
    local authCfg = { centered = true, suffix = "", spacing = 10, xOffset = -18 }
    Text:CreateDoubleLine(container, "Author", "EEsto", authCfg)
    Text:CreateDoubleLine(container, "Realm", "Sanguino (EU)", authCfg)

    -- Espaciador manual
    local spacer = CreateFrame("Frame", nil, container)
    spacer:SetHeight(25)

    -- 4. Enlaces Oficiales
    local links = {
        { "Wago.io:", "addons.wago.io/addons/ghostui" },
        { "CurseForge:", "curseforge.com/wow/addons/ghostui" },
        { "WoWInterface:", "wowinterface.com/downloads/info26734-GhostUI" },
        { "GitHub:", "github.com/Estasleyendoesto/GhostUI" }
    }
    
    for _, l in ipairs(links) do 
        Link:Create(container, l[1], l[2]) 
    end

    -- 5. Traductores (Sección escalable)
    -- Para activarla, descomenta el bloque y ajusta el padding.top a 8 en el Layout final.
    --[[
    local sharedOffset = 18
    CreateFrame("Frame", nil, container):SetHeight(35)
    
    Text:CreateSingleLine(container, "SPECIAL THANKS TO OUR TRANSLATORS", {
        align = "LEFT", 
        xOffset = sharedOffset, 
        color = {1, 0.82, 0}, 
        font = "GameFontNormalSmall"
    })

    local translators = {
        { "deDE", "SlayerEGT, maylisdalan" },
        { "esES", "neolynx_zero, maylisdalan, xNumb97" },
        { "frFR", "PhantomLord, maylisdalan" },
        { "koKR", "drixwow, Hayan, netaras" }
    }

    for _, t in ipairs(translators) do
        Text:CreateDoubleLine(container, t[1], t[2], { 
            offset = sharedOffset - 15, 
            labelWidth = 50, 
            spacing = 10 
        })
    end
    --]]

    -- 6. Configuración Final del Layout
    -- Si activas los traductores, cambia top a 8 para que todo quepa sin scroll.
    Utils:RegisterLayout(container, {
        padding = { left = 110, right = 90, top = 48, bottom = 60 },
        spacing = 8
    })
    
    Utils:VStack(container)
end